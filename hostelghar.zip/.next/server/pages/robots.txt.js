"use strict";(()=>{var e={};e.id=80,e.ids=[80],e.modules={1323:(e,t)=>{Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},6294:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{config:()=>S,default:()=>P,getServerSideProps:()=>g,getStaticPaths:()=>d,getStaticProps:()=>c,reportWebVitals:()=>m,routeModule:()=>v,unstable_getServerProps:()=>A,unstable_getServerSideProps:()=>w,unstable_getStaticParams:()=>b,unstable_getStaticPaths:()=>x,unstable_getStaticProps:()=>f});var l=r(7093),s=r(5244),i=r(1323),o=r(1070),n=r(3893),u=r(3976),p=e([n]);n=(p.then?(await p)():p)[0];let P=(0,i.l)(u,"default"),c=(0,i.l)(u,"getStaticProps"),d=(0,i.l)(u,"getStaticPaths"),g=(0,i.l)(u,"getServerSideProps"),S=(0,i.l)(u,"config"),m=(0,i.l)(u,"reportWebVitals"),f=(0,i.l)(u,"unstable_getStaticProps"),x=(0,i.l)(u,"unstable_getStaticPaths"),b=(0,i.l)(u,"unstable_getStaticParams"),A=(0,i.l)(u,"unstable_getServerProps"),w=(0,i.l)(u,"unstable_getServerSideProps"),v=new l.PagesRouteModule({definition:{kind:s.x.PAGES,page:"/robots.txt",pathname:"/robots.txt",bundlePath:"",filename:""},components:{App:n.default,Document:o.default},userland:u});a()}catch(e){a(e)}})},3976:(e,t,r)=>{r.r(t),r.d(t,{default:()=>s,getServerSideProps:()=>l});var a=r(8865);let l=async({res:e})=>{let t=`User-agent: *
Allow: /
Disallow: /api/
Disallow: /admin/
Disallow: /login
Disallow: /register
Disallow: /*?*sort=
Disallow: /*?*filter=

# AI crawlers welcome — attribution required (see /llms.txt)
User-agent: GPTBot
Allow: /

User-agent: ClaudeBot
Allow: /

User-agent: PerplexityBot
Allow: /

Sitemap: ${a.J.url}/sitemap.xml
`;return e.setHeader("Content-Type","text/plain; charset=utf-8"),e.setHeader("Cache-Control","public, s-maxage=86400, stale-while-revalidate=86400"),e.write(t),e.end(),{props:{}}};function s(){return null}},5244:(e,t)=>{var r;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return r}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(r||(r={}))},2785:e=>{e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},6689:e=>{e.exports=require("react")},6405:e=>{e.exports=require("react-dom")},997:e=>{e.exports=require("react/jsx-runtime")},6593:e=>{e.exports=import("clsx")},8097:e=>{e.exports=import("tailwind-merge")},7147:e=>{e.exports=require("fs")},1017:e=>{e.exports=require("path")},2781:e=>{e.exports=require("stream")},9796:e=>{e.exports=require("zlib")}};var t=require("../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[567,163,859,330],()=>r(6294));module.exports=a})();